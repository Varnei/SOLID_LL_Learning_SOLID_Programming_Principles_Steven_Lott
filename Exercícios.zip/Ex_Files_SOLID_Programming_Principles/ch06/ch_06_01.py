"""S.O.L.I.D Design.

Chapter 6, SRP. Part 1.
"""

class Simulator:
    def __init__(self, house, player):
        pass
    def run(self):
        pass
    @property
    def final_stats(self):
        pass
